#!/usr/bin/env python3
"""Тима Осадок QC: ZIP/MP4 audit + cache + SRT checks + conservative version diff.
Requires: ffmpeg, ffprobe, Python >=3.10, numpy, opencv-python.
No speech recognition is claimed or performed; import SRT from ASR separately.
"""
from __future__ import annotations
import argparse, concurrent.futures, csv, datetime, difflib, hashlib, html, json, math, os, re, shutil, statistics, subprocess, sys, time, zipfile, uuid
from pathlib import Path
import numpy as np
import cv2

VERSION = '2.2.0-rick'
VIDEO_EXT = {'.mp4', '.mov', '.mkv'}
SUB_EXT = {'.srt'}
SAFE_MARGIN = {'tiktok': {'left':.10,'right':.79,'top':.125,'bottom':.65},
               'reels': {'left':.10,'right':.85,'top':.14,'bottom':.72},
               'shorts': {'left':.10,'right':.84,'top':.13,'bottom':.72}}
MAX_ZIP_TOTAL = 2 * 1024**3
MAX_ZIP_FILES = 150
# Conservative, heuristic user-preference check. Not a TikTok policy determination.
UNCENSORED_WORDS = re.compile(r'(?iu)\b(?:бля\w*|хуйн\w*|хуй\w*|хуе\w*|охуе\w*|пизд\w*|[её]бан\w*|сука)\b')

def sh(args, timeout=120):
    r = subprocess.run(args, capture_output=True, text=True, errors='replace', timeout=timeout)
    if r.returncode:
        raise RuntimeError((' '.join(map(str,args[:5])) + ': ' + r.stderr[-1000:]))
    return r.stdout

def sha(path):
    h=hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def video_id(path):
    """Match common export names to stable clip IDs, independently of version/copy suffix.

    Examples: 01_Дисциплина_V5(1).mp4, 01_Дисциплина_V5.srt,
    Лайфхак_1_Рик_V2.mp4, clip_01_AUTO.srt -> clip_1.
    Do not guess IDs for a name with a number in the middle of an unrelated title.
    """
    n=Path(path).stem.lower().strip()
    n=re.sub(r'\(\d+\)$','',n).strip()
    match=re.match(r'^(?:лайфхак|clip|video|ролик)[_\s-]*0*(\d+)(?:$|[_\s.-])',n)
    if not match:
        match=re.match(r'^0*(\d+)(?:$|[_\s.-])',n)
    if match:
        return f'clip_{int(match.group(1))}'
    fallback=re.sub(r'[_\s.-]*v\d+(?:[_\s.-].*)?$', '', n)
    return re.sub(r'[^a-z0-9а-яё]+','_',fallback).strip('_')

def unpack_safe(src, dst):
    dst.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(src) as z:
        infos=[x for x in z.infolist() if not x.is_dir()]
        if len(infos)>MAX_ZIP_FILES or sum(x.file_size for x in infos)>MAX_ZIP_TOTAL:
            raise ValueError('Archive too large: possible ZIP bomb')
        out=[]; seen=set()
        for i in infos:
            target=dst / Path(i.filename.replace('\\','/')).name
            if not target.name or target.suffix.lower() not in VIDEO_EXT|SUB_EXT:continue
            folded=target.name.casefold()
            if folded in seen:raise ValueError('Duplicate flattened filename INSIDE ZIP: '+target.name)
            seen.add(folded)
            # Safe to rerun the same archive in the same output directory. If the
            # archived file changed, replace it atomically instead of using stale bytes.
            tmp=target.with_name(target.name+'.tmp-qc')
            try:
                with z.open(i) as fr, open(tmp,'wb') as fw:shutil.copyfileobj(fr,fw)
                if target.exists() and sha(tmp)==sha(target):
                    tmp.unlink()
                else:
                    tmp.replace(target)
            finally:
                if tmp.exists():tmp.unlink()
            out.append(target)
        return out

def probe(path):
    p=json.loads(sh(['ffprobe','-v','error','-show_format','-show_streams','-of','json',str(path)],25))
    v=next((x for x in p['streams'] if x['codec_type']=='video'),None)
    a=next((x for x in p['streams'] if x['codec_type']=='audio'),None)
    if not v: raise ValueError('No video stream')
    fps=v.get('avg_frame_rate','0/1')
    try: num,den=map(float,fps.split('/')); rate=num/den if den else 0
    except: rate=0
    return {'width':v.get('width'), 'height':v.get('height'), 'fps':round(rate,3),
            'duration':round(float(p.get('format',{}).get('duration',v.get('duration',0))),3),
            'video_codec':v.get('codec_name'), 'audio_codec':(a or {}).get('codec_name'),
            'audio_channels':(a or {}).get('channels'), 'bitrate':p.get('format',{}).get('bit_rate')}

def hhmm(t):
    m,s=divmod(max(0,float(t)),60);h,m=divmod(int(m),60)
    return f'{h:02}:{m:02}:{s:06.3f}'

def sec(s):
    s=s.strip().replace(',','.')
    p=s.split(':');return sum(float(x)*(60**i) for i,x in enumerate(reversed(p)))

def parse_srt_detailed(path):
    raw=path.read_text(encoding='utf-8-sig',errors='replace').replace('\r\n','\n').strip()
    blocks=re.split(r'\n\s*\n',raw) if raw else []
    entries=[];bad=[]
    for number,block in enumerate(blocks,1):
        lines=block.strip().split('\n')
        idx=next((i for i,line in enumerate(lines) if '-->' in line),None)
        if idx is None:
            bad.append(issue('SRT_BAD_CUE',0,'error',f'Cue {number}: missing --> timing', 'Fix malformed SRT block'))
            continue
        try:
            a,b=[z.strip() for z in lines[idx].split('-->',1)]
            start,end=sec(a),sec(b)
            if not math.isfinite(start) or not math.isfinite(end) or start<0:raise ValueError('invalid value')
        except Exception:
            bad.append(issue('SRT_BAD_TIME',0,'error',f'Cue {number}: malformed time', 'Fix SRT timecode'))
            continue
        text_lines=[line.strip() for line in lines[idx+1:]]
        if not any(text_lines):
            bad.append(issue('SRT_EMPTY_CUE',start,'warning',f'Cue {number}: no text', 'Remove or fill empty cue'))
        entries.append({'start':start,'end':end,'text':' '.join(text_lines),'lines':text_lines})
    return entries,bad

def parse_srt(path):
    return parse_srt_detailed(path)[0]

def subtitles_check(entries, duration):
    issues=[];gaps=[]
    for i,x in enumerate(entries):
        text=x['text']; dur=x['end']-x['start']
        if dur<=0:issues.append(issue('SRT_TIME_INVALID',x['start'],'critical','SRT end <= start','Fix SRT timing'))
        if x['end']>duration+0.1:issues.append(issue('SRT_BEYOND_END',x['start'],'error','SRT beyond video end','Trim SRT timing'))
        if i and x['start']<entries[i-1]['end']-.02:
            issues.append(issue('SRT_OVERLAP',x['start'],'warning','Overlapping SRT cues','Review subtitle rhythm'))
        n=len(text);cps=n/max(.01,dur)
        if cps>22:issues.append(issue('SRT_FAST',x['start'],'warning',f'{cps:.1f} characters/s','Shorten caption or increase visibility duration'))
        if max((len(l) for l in x['lines']),default=0)>45:
            issues.append(issue('SRT_LINE_LONG',x['start'],'warning','Text line >45 characters','Break line before rendering'))
        # Tima's editorial rule for TikTok: no visible unmasked strong profanity.
        # Do not automatically rewrite or claim a platform ban; human approves a mask/synonym.
        matches=sorted(set(m.group(0) for m in UNCENSORED_WORDS.finditer(text)))
        if matches:
            issues.append(issue('SRT_PROFANITY_REVIEW',x['start'],'warning',
                'Visible potentially uncensored words: '+', '.join(matches),
                'Use a censored spelling or approved neutral synonym in on-screen text; confirm final burned-in frame'))
    # Detect repeated words and repeat phrases: heuristic, never auto-delete
    norm=[w.lower().replace('ё','е') for e in entries for w in re.findall(r'[а-яёa-z]+',e['text'].lower())]
    repeated=[]
    for i in range(len(norm)-2):
        if norm[i]==norm[i+1] and len(norm[i])>3 and len(repeated)<10:repeated.append(norm[i])
    return issues,{'cues':len(entries),'repeated_words_candidates':repeated,'start_at':entries[0]['start'] if entries else None}

def issue(code,t,severity,detail,action,evidence='signal'):
    return {'code':code,'time_s':round(float(t),2),'timecode':hhmm(t),'severity':severity,'detail':detail,'action':action,'evidence':evidence}

def audio_metrics(path,duration):
    # Two runs: FFmpeg analysis logs and waveform slices. Some codecs have no audio.
    cmd=['ffmpeg','-hide_banner','-nostats','-i',str(path),'-af',
         'ebur128=peak=true,silencedetect=noise=-35dB:d=0.6','-f','null','-']
    r=subprocess.run(cmd,capture_output=True,text=True,errors='replace',timeout=120)
    log=r.stderr
    sil=[]
    for m in re.finditer(r'silence_start:\s*([0-9.]+).*?silence_end:\s*([0-9.]+)', log, re.S):
        a,b=float(m.group(1)),float(m.group(2))
        if 0<=a<b<=duration+.1:sil.append([round(a,2),round(b,2)])
    loud=None
    mi=re.findall(r'I:\s*(-?\d+\.\d+)\s+LUFS',log)
    if mi:loud=float(mi[-1])
    peak=None
    pk=re.findall(r'(?m)^\s*Peak:\s*(-?[0-9.]+)\s*dBFS\s*$',log)
    if pk:peak=float(pk[-1])
    audio_issue=[]
    for a,b in sil:
        if a>.3 and b<duration-.3:
            audio_issue.append(issue('SILENCE_GAP',a,'review',f'Possible pause/silence {b-a:.2f}s ({a:.2f}-{b:.2f})',
                                     'Listen in context; silence can be expressive'))
    # Compare short-time RMS in 0.1 sec windows, candidate abrupt audio level changes
    x=subprocess.run(['ffmpeg','-v','error','-i',str(path),'-vn','-ac','1','-ar','8000',
                      '-f','f32le','-'],capture_output=True,timeout=120).stdout
    arr=np.frombuffer(x,dtype='<f4')
    ms=[];step=800
    for k in range(0,len(arr)-step,step):
        y=arr[k:k+step];ms.append(float(20*np.log10(max(1e-8,np.sqrt(np.mean(y*y))))))
    # only voice-like rms bands, transitions >10 dB between adjacent adjacent windows
    for i in range(3,len(ms)-3):
        left=np.median(ms[i-2:i]);right=np.median(ms[i:i+2]);t=i*.1
        if abs(right-left)>12 and min(left,right)>-43 and t>.6 and t<duration-.6:
            if not audio_issue or not any(z['code']=='LEVEL_JUMP_CANDIDATE' and abs(z['time_s']-t)<.55 for z in audio_issue):
                audio_issue.append(issue('LEVEL_JUMP_CANDIDATE',t,'review',f'Local RMS changed by {right-left:+.1f} dB',
                                         'Listen only if aligned with an actual video cut; speech dynamics alone are not errors'))
    return {'integrated_lufs':loud,'true_peak_dbfs':peak,'silences':sil,
            'audio_issues':audio_issue[:40], 'rms_100ms_dbfs':ms[::5],
            'audio_samples_8khz':len(arr)}

def dhash(frame):
    g=cv2.cvtColor(cv2.resize(frame,(9,8)),cv2.COLOR_BGR2GRAY)
    bits=(g[:,:-1]>g[:,1:]).flatten()
    k=0
    for v in bits:k=(k<<1)|int(v)
    return format(k,'016x')

def detect_frame_metrics(path,duration,thumb_dir=None, make_thumbs=False):
    # actual decoded images at 2 fps, sampled: no claims of frame-by-frame coverage
    cmd=['ffmpeg','-v','error','-i',str(path),'-vf','fps=2,scale=180:320:flags=bilinear',
         '-pix_fmt','bgr24','-f','rawvideo','-']
    p=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    wh=180*320*3; i=0;prev=None;frame_metrics=[]; face_none=[]; cuts=[];prev_diff=[]
    cascade_file=cv2.data.haarcascades+'haarcascade_frontalface_default.xml'
    cascade=cv2.CascadeClassifier(cascade_file)
    sample_t={round(j*duration/7,1) for j in range(1,7)}
    thumbs=[]
    while True:
        b=p.stdout.read(wh)
        if len(b)<wh:break
        frame=np.frombuffer(b,np.uint8).reshape((320,180,3)).copy()
        grey=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY);t=i*.5
        blur=float(cv2.Laplacian(grey,cv2.CV_64F).var());brightness=float(np.mean(grey));
        face=cascade.detectMultiScale(grey,scaleFactor=1.1,minNeighbors=4,minSize=(18,18))
        # faces missing is only a weak signal; not proof frame is empty
        faces=len(face);face_none.append((t,faces))
        diff=float(np.mean(cv2.absdiff(frame,prev))) if prev is not None else 0.0
        cuts.append((t,diff))
        f={'time_s':round(t,2),'dhash':dhash(frame),'blur_laplacian':round(blur,1),
           'luma':round(brightness,1),'faces_haar':faces,'frame_mad':round(diff,2)}
        frame_metrics.append(f)
        if make_thumbs and any(abs(t-x)<.25 for x in sample_t):thumbs.append((t,frame.copy()))
        prev=frame;i+=1
    p.stdout.close();p.wait(timeout=30)
    if make_thumbs and thumb_dir:
        thumb_dir=Path(thumb_dir);thumb_dir.mkdir(parents=True,exist_ok=True)
        if thumbs:
            w=6*180;h=320+30;canvas=np.full((h,w,3),238,dtype=np.uint8)
            for j,(t,im) in enumerate(thumbs[:6]):
                canvas[30:350,j*180:(j+1)*180]=im
                cv2.putText(canvas,hhmm(t),(j*180+4,20),cv2.FONT_HERSHEY_SIMPLEX,.45,(20,20,20),1)
            cv2.imwrite(str(thumb_dir/'contact.jpg'),canvas)
    isues=[]
    # consecutive periods without recognized face surrounded by detected face, >= 4 seconds
    any_face=sum(x['faces_haar']>0 for x in frame_metrics)
    if any_face>=4:
        starts=[];running=None
        for j,x in enumerate(frame_metrics+[{'faces_haar':1,'time_s':duration}]):
            if x['faces_haar']==0 and running is None:running=j
            elif x['faces_haar']>0 and running is not None:
                if j-running>=8 and running>=3 and j<len(frame_metrics)-2:
                    isues.append(issue('FACE_ABSENT_CANDIDATE',frame_metrics[running]['time_s'],'review',
                        f'No Haar frontal-face detections for {(j-running)*.5:.1f}s',
                        'Check original framing; side view, movement or obscured face may be intentional'))
                running=None
    # cut candidates relative to adjacent frames, threshold tuned to 2fps proxy
    ds=np.array([x['frame_mad'] for x in frame_metrics]); baseline=float(np.median(ds[ds>0])) if np.any(ds>0) else 0
    for j,x in enumerate(frame_metrics):
        if x['frame_mad']>max(30,baseline*3) and x['time_s']>.5:
            if not isues or not any(q['code']=='VISUAL_CHANGE_CANDIDATE' and abs(q['time_s']-x['time_s'])<1 for q in isues):
                isues.append(issue('VISUAL_CHANGE_CANDIDATE',x['time_s'],'review',
                    f'Inter-frame pixel change {x["frame_mad"]:.1f} (2 fps proxy)',
                    'Review cut/gesture at higher fps; not proof of editing error'))
    very_dark=[x['time_s'] for x in frame_metrics if x['luma']<14]
    if len(very_dark)>=4:
        isues.append(issue('DARK_FRAMES',very_dark[0],'review',f'{len(very_dark)} dark sampled frames',
                           'Check artistic intention vs unwanted dark frames'))
    return {'frames_checked':len(frame_metrics),'sample_rate_fps':2,
            'face_detected_frames':sum(x['faces_haar']>0 for x in frame_metrics),
            'median_brightness':round(statistics.median(x['luma'] for x in frame_metrics),1) if frame_metrics else None,
            'median_blur':round(statistics.median(x['blur_laplacian'] for x in frame_metrics),1) if frame_metrics else None,
            'frame_metrics':frame_metrics,'visual_issues':isues[:40]}

def subtitle_box_checks(json_path, clipid, platform='tiktok'):
    if not json_path or not Path(json_path).exists():return {'status':'not_tested','reason':'No subtitle bounding-box export supplied'},[]
    source=json.loads(Path(json_path).read_text(encoding='utf-8'))
    boxes=source.get(clipid,[]);issues=[];bounds=SAFE_MARGIN[platform]
    if not boxes:return {'status':'not_tested','reason':'No subtitle bounding boxes for clip '+clipid},[]
    for x in boxes:
        px,py,w,h=x['box']
        if px<bounds['left'] or py<bounds['top'] or px+w>bounds['right'] or py+h>bounds['bottom']:
            issues.append(issue('SUBTITLE_SAFE_ZONE',x.get('start',0),'warning',
                f'Bounding box {x["box"]} outside conservative {platform} overlay',
                'Move subtitles into editor safe-zone preview; validate platform UI manually'))
    return {'status':'checked_against_approximate_template','platform':platform,'boxes_tested':len(boxes)},issues

def gather_archive(src, dst):
    src=Path(src)
    if src.suffix.lower()=='.zip':return unpack_safe(src,dst)
    if src.is_dir():return sorted(x for x in src.iterdir() if x.suffix.lower() in VIDEO_EXT|SUB_EXT)
    if src.suffix.lower() in VIDEO_EXT|SUB_EXT:return [src]
    raise ValueError('Use ZIP or directory containing MP4 and SRT')

def audit_single(path, srt_path, data_dir, cache_dir, box_path=None, platform='tiktok'):
    t0=time.perf_counter();fingerprint=sha(path)
    key=hashlib.sha256((fingerprint+'|'+VERSION).encode()).hexdigest()
    cached=cache_dir/(key+'.json')
    if cached.exists():
        base=json.loads(cached.read_text(encoding='utf-8'));hit=True
    else:
        pr=probe(path)
        if not pr['audio_codec']:
            au={'integrated_lufs':None,'true_peak_dbfs':None,'silences':[],
                'audio_issues':[issue('AUDIO_MISSING',0,'critical','No audio stream in video',
                                      'Restore original soundtrack before delivery')],
                'rms_100ms_dbfs':[],'audio_samples_8khz':0}
        else:
            au=audio_metrics(path,pr['duration'])
            if au.get('audio_samples_8khz',0)==0:
                au['audio_issues'].append(issue('AUDIO_DECODE_FAILED',0,'critical',
                    'Audio stream exists but PCM decoder returned no samples',
                    'Re-export and verify audible audio track'))
        vi=detect_frame_metrics(path,pr['duration'],data_dir/path.stem,make_thumbs=True)
        if vi['frames_checked']==0:
            vi['visual_issues'].append(issue('VIDEO_DECODE_FAILED',0,'critical',
                'No frames decoded in 2fps proxy', 'Re-export video; test full playback'))
        # Suppress dozens of false alarms from natural voice dynamics: only cross-correlate
        # RMS jumps with an independent visual cut candidate, otherwise keep as measurements.
        vis_times=[z['time_s'] for z in vi['visual_issues'] if z['code']=='VISUAL_CHANGE_CANDIDATE']
        audio_jumps=[z for z in au['audio_issues'] if z['code']=='LEVEL_JUMP_CANDIDATE']
        au['rms_jump_candidates_all']=len(audio_jumps)
        au['audio_issues']=[z for z in au['audio_issues'] if z['code']!='LEVEL_JUMP_CANDIDATE']
        audio_confirm=[z for z in audio_jumps if any(abs(z['time_s']-t)<.5 for t in vis_times)]
        # Still review candidates, not proof of a mistake; max 3 per clip.
        au['audio_issues']+=audio_confirm[:3]
        issues=au['audio_issues']+vi['visual_issues']
        if pr['width']*16!=pr['height']*9:
            issues.append(issue('ASPECT_RATIO',0,'warning',f"{pr['width']}x{pr['height']} is not exact 9:16",'Inspect crop/export preset'))
        if pr['width']<720 or pr['height']<1280:
            issues.append(issue('LOW_RES',0,'review',f"{pr['width']}x{pr['height']}",'Check source quality and target output resolution'))
        base={'path':str(path),'name':path.name,'clip_id':video_id(path),'sha256':fingerprint,
              'probe':pr,'audio':au,'video':vi,'issues':issues,'detectors_version':VERSION,
              'limits':['No native ASR','No direct listening','Video sampled at 2fps',
                         'Haar face detector can miss profile faces','No lip-sync verification']}
        # V2.2 safety fix: two different clips with identical media bytes may
        # compute the same cache key concurrently. Never publish a half-written
        # JSON file that another QC worker could read during deserialization.
        temp_cache=cached.with_name(cached.name+'.'+uuid.uuid4().hex+'.tmp')
        try:
            temp_cache.write_text(json.dumps(base,ensure_ascii=False,indent=2),encoding='utf-8')
            os.replace(temp_cache,cached)
        finally:
            temp_cache.unlink(missing_ok=True)
        hit=False
    # SRT and overlay checks always recomputed, never cache without hash
    data=json.loads(json.dumps(base,ensure_ascii=False))
    entries,parse_issues=parse_srt_detailed(srt_path) if srt_path else ([],[])
    si,stats=subtitles_check(entries,data['probe']['duration'])
    si=parse_issues+si
    if not srt_path:
        stats['status']='not_tested_no_srt'
        si.append(issue('SRT_MISSING',0,'error', 'No matching external SRT for this clip',
                        'Supply a clip-matched SRT. Cannot approve subtitle accuracy'))
    elif not entries:
        stats['status']='invalid_or_empty_srt'
        si.append(issue('SRT_EMPTY',0,'error','No usable subtitle cues', 'Review actual SRT'))
    else:stats['status']='checked_srt_timing_readability_not_audio_accuracy'
    region,ri=subtitle_box_checks(box_path,data['clip_id'],platform)
    data['subtitle_regions']=region;data['subtitles']=stats;data['srt_path']=str(srt_path) if srt_path else None
    data['issues']=data['issues']+si+ri;data['cache_hit']=hit
    # Correct metadata on cache hits from another directory with same file bytes.
    data['path']=str(path);data['name']=path.name;data['clip_id']=video_id(path)
    data['runtime_s']=round(time.perf_counter()-t0,3)
    return data

def compare_reports(old,new):
    if old['sha256']==new['sha256']:
        return {'old':old['name'],'new':new['name'],'same_binary':True,'status':'identical_file',
                'reusable_checks':'Only media technical measurements can be reused; SRT, boxes, locks and editorial approval are evaluated separately',
                'changed_ranges_new_seconds':[],'unchanged_blocks':[]}
    a=[int(x['dhash'],16) for x in old['video']['frame_metrics']]
    b=[int(x['dhash'],16) for x in new['video']['frame_metrics']]
    # Find shifted subsequences despite lossy re-encoding. This is a perceptual proxy,
    # not definitive content identity. Match if <= 8 of 64 dHash bits differ.
    candidates=[]
    for offset in range(-len(b)+4,len(a)-3):
        j0=max(0,-offset);j1=min(len(b),len(a)-offset)
        if j1-j0<5:continue
        matchmask=[(a[j+offset]^b[j]).bit_count()<=8 for j in range(j0,j1)]
        start=None;end=None; misses=0
        for pos in range(len(matchmask)+1):
            hit=pos<len(matchmask) and matchmask[pos]
            if hit and start is None:start=pos;end=pos+1;misses=0
            elif hit:end=pos+1;misses=0
            elif start is not None and pos<len(matchmask) and misses<1:
                misses+=1
            elif start is not None:
                if end-start>=6 and sum(matchmask[start:end])/(end-start)>=.8:
                    j=j0+start;i=j+offset
                    candidates.append((end-start,i,j))
                start=None;end=None;misses=0
    blocks=[];used_old=set();used_new=set()
    for n,i,j in sorted(candidates,reverse=True):
        # Avoid contradictory alignments between two matching sections.
        if any((i+k in used_old or j+k in used_new) for k in range(n)):
            continue
        used_old.update(range(i,i+n));used_new.update(range(j,j+n))
        blocks.append({'old_s':[i*.5,(i+n)*.5],'new_s':[j*.5,(j+n)*.5],
                       'duration_s':n*.5,'status':'visually_similar_proxy_not_proof_audio_unchanged'})
    blocks.sort(key=lambda z:z['new_s'][0])
    change=[];pos=0
    for bl in blocks:
        if bl['new_s'][0]>pos+.25:change.append([round(pos,2),round(bl['new_s'][0],2)])
        pos=max(pos,bl['new_s'][1])
    duration=new['probe']['duration']
    if pos<duration-.25:change.append([round(pos,2),duration])
    old_removed=[];oldpos=0
    for bl in sorted(blocks,key=lambda z:z['old_s'][0]):
        if bl['old_s'][0]>oldpos+.25:old_removed.append([round(oldpos,2),round(bl['old_s'][0],2)])
        oldpos=max(oldpos,bl['old_s'][1])
    if oldpos<old['probe']['duration']-.25:old_removed.append([round(oldpos,2),old['probe']['duration']])
    # Change log is conservative: the absence of a flag does not prove an edit is repaired.
    old_issues=old.get('issues',[]);new_issues=new.get('issues',[])
    def mapped_time(t):
        for block in blocks:
            if block['old_s'][0]<=t<=block['old_s'][1]:
                return block['new_s'][0]+(t-block['old_s'][0])
        return None
    new_codes={(x['code'],round(x['time_s'])) for x in new_issues}
    not_automatically_confirmed=[]
    for x in old_issues:
        t=mapped_time(x['time_s'])
        if t is None:
            not_automatically_confirmed.append({'code':x['code'],'old_at_s':x['time_s'],
               'status':'old_region_changed_or_not_matched','proof_of_fix':False})
        elif not any(y['code']==x['code'] and abs(y['time_s']-t)<=1 for y in new_issues):
            not_automatically_confirmed.append({'code':x['code'],'old_at_s':x['time_s'],
                'status':'old_flag_absent_in_reanalysis','proof_of_fix':False})
    new_flags=[]
    for y in new_issues:
        if not any(x['code']==y['code'] and mapped_time(x['time_s']) is not None and
                   abs(mapped_time(x['time_s'])-y['time_s'])<=1 for x in old_issues):
            new_flags.append({'code':y['code'],'new_at_s':y['time_s'],'status':'new_or_shifted_candidate'})
    return {'old':old['name'],'new':new['name'],'same_binary':False,
            'new_flags_to_review':new_flags[:100], 'old_flags_not_confirmed_as_fixed':not_automatically_confirmed[:100],
            'duration_delta_s':round(duration-old['probe']['duration'],3),
            'visual_similarity_proxy_coverage_ratio':round(sum(x['duration_s'] for x in blocks)/max(.1,duration),3),
            'unchanged_blocks':blocks[:80], 'changed_ranges_new_seconds':change, 'removed_or_unmatched_ranges_old_seconds':old_removed,
            'status':'approximate_visual_matching_only',
            'warning':'2fps dHash may miss identical edits or falsely match repetitive talking-head shots. Different crop/codec defeats matching; matches never prove audio, subtitle or pixel identity.'}

def load_report_dir(src):
    src=Path(src)
    s=src/'run_summary.json' if src.is_dir() else src
    obj=json.loads(s.read_text(encoding='utf-8'))
    return {x['clip_id']:x for x in obj['clips']}

def export_html(out,results,comparisons=None):
    cells=[]
    for x in results:
        issues=x['issues'];cnt={s:sum(a['severity']==s for a in issues) for s in ['critical','error','warning','review']}
        issue_rows=''.join('<tr><td>'+html.escape(z['timecode'])+'</td><td>'+html.escape(z['code'])+'</td><td>'+html.escape(z['detail'])+'</td><td>'+html.escape(z['action'])+'</td></tr>' for z in issues)
        thumb=out/'frames'/Path(x['name']).stem/'contact.jpg'
        uri=thumb.relative_to(out).as_posix() if thumb.exists() else ''
        cells.append(f'''<section><h2>{html.escape(x['name'])}</h2><p>⌚ {x['probe']['duration']} s · {x['probe']['width']}×{x['probe']['height']} · fps {x['probe']['fps']} · LUFS {x['audio']['integrated_lufs']} · True peak {x['audio']['true_peak_dbfs']} dBFS</p><p><b>Issues:</b> {cnt} · SRT cues {x['subtitles']['cues']} · subtitle placement {x['subtitle_regions']['status']} · cache {x['cache_hit']}</p>{f'<img src="{uri}" width="900" alt="Contact sheet">' if uri else ''}<table><tr><th>At</th><th>Code</th><th>Evidence</th><th>Action</th></tr>{issue_rows}</table></section>''')
    comp=''
    if comparisons:
        comp='<h2>Version diff</h2><pre>'+html.escape(json.dumps(comparisons,ensure_ascii=False,indent=2))+'</pre>'
    htmlcode='''<!doctype html><html lang="ru"><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Тима Осадок — QC</title><style>body{font:15px/1.5 system-ui;background:#0b1425;color:#f0f5fc;max-width:1120px;margin:36px auto;padding:12px}h1{font-size:30px}h2{margin-top:38px}section{border:1px solid #2a3f5e;padding:22px;border-radius:16px;margin:24px 0;background:#111e33}img{max-width:100%;border-radius:10px}table{border-collapse:collapse;width:100%}td,th{padding:9px;border-bottom:1px solid #31455c;text-align:left;vertical-align:top}th{color:#9bb4d1}p{color:#c7d3e4}pre{white-space:pre-wrap;overflow-wrap:anywhere}small{color:#aec1d9}</style><h1>Тима Осадок — техническая проверка</h1><p>Автоматические сигналы ≠ доказанные монтажные ошибки. Нет автоматической проверки художественного качества.</p>'''+''.join(cells)+comp+'</html>'
    (out/'report.html').write_text(htmlcode,encoding='utf-8')

def read_creative_locks(path):
    """Creative exceptions are a protected author decision, NOT proof of a valid cut.
    Never allow a lock to silence SRT, broken audio or decode errors.
    """
    if not path:return {}
    root=json.loads(Path(path).read_text(encoding='utf-8'))
    clips=root.get('clips',root)
    if not isinstance(clips,dict):raise ValueError('locks JSON must contain clip mapping')
    for cid,records in clips.items():
        if not isinstance(records,list):raise ValueError('lock intervals must be list for '+cid)
        for rec in records:
            if not (0<=float(rec['start_s'])<float(rec['end_s'])):
                raise ValueError('Invalid creative lock interval for '+cid)
            if not str(rec.get('reason','')).strip():raise ValueError('Creative lock requires reason for '+cid)
    return clips

def apply_creative_locks(data,locks):
    applied=[];left=[]
    for flag in data['issues']:
        matched=None
        for lk in locks.get(data['clip_id'],[]):
            if (float(lk['start_s'])<=flag['time_s']<=float(lk['end_s']) and
                flag['code'] in lk.get('codes',['FACE_ABSENT_CANDIDATE'])):
                matched=lk;break
        if matched:
            applied.append({'flag':flag,'reason':matched['reason'],
                'status':'intentional_visual_exception_not_automatic_quality_approval'})
        else:left.append(flag)
    data['issues']=left
    data['creative_exceptions']=applied
    data['creative_locks']=locks.get(data['clip_id'],[])
    return data

def map_srts(srts):
    result={};dups={}
    for p in sorted(srts,key=lambda x:str(x)):
        key=video_id(p)
        if key in result:
            if sha(result[key]) != sha(p):
                dups.setdefault(key,[str(result[key])]).append(str(p))
        else:result[key]=p
    if dups:
        raise ValueError('Ambiguous different SRTs for same clip ID; keep only one per clip: '+json.dumps(dups,ensure_ascii=False))
    return result

def run(args):
    output=Path(args.output).resolve();output.mkdir(parents=True,exist_ok=True)
    t0=time.perf_counter();paths=gather_archive(args.input,output/'_unpacked')
    vids=[p for p in paths if p.suffix.lower() in VIDEO_EXT]
    srts=[p for p in paths if p.suffix.lower() in SUB_EXT]
    if args.srt_dir:
        srts.extend(x for x in Path(args.srt_dir).glob('*.srt'))
    srts_map=map_srts(srts)
    locks=read_creative_locks(args.locks)
    # A ZIP with 5 MP4 and 5 SRT must map each pair; duplicate video IDs are unsafe.
    seen_ids={}
    for p in vids:
        key=video_id(p)
        if key in seen_ids:raise ValueError(f'Duplicate clip ID {key}: {seen_ids[key]} AND {p}')
        seen_ids[key]=str(p)
    cache_dir=output/'cache';cache_dir.mkdir(exist_ok=True)
    (output/'frames').mkdir(exist_ok=True)
    if not vids:raise ValueError('No MP4 found')
    tasks=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(args.workers,4)) as pool:
        for p in vids:
            tasks.append(pool.submit(audit_single,p,srts_map.get(video_id(p)),output/'frames',cache_dir,args.boxes,args.platform))
        results=[]
        for task in concurrent.futures.as_completed(tasks):results.append(task.result())
    results.sort(key=lambda x:x['clip_id'])
    results=[apply_creative_locks(x,locks) for x in results]
    comparisons=[]
    if args.compare_old:
        olds=load_report_dir(args.compare_old)
        for r in results:
            old=olds.get(r['clip_id'])
            if old:comparisons.append(compare_reports(old,r))
    summary={'tool':'tima_qc','version':VERSION,'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'input':str(args.input),'analysis_time_s':round(time.perf_counter()-t0,3),
             'workers':args.workers,'clips':results,'comparisons':comparisons,
             'technical_gate':'NEEDS_REVIEW' if any(x['issues'] for x in results) else 'NO_AUTOMATED_FLAGS',
             'human_audio_check':'NOT_PERFORMED_BY_SCRIPT',
             'human_artistic_approval':'NOT_PERFORMED_BY_SCRIPT',
             'limitations_important':'NO_AUTOMATIC_PUBLICATION_APPROVAL',
             'limits':[
                'No speaker transcription; only externally provided SRT text/timing',
                'No forced alignment: cannot establish word-level accuracy',
                'No automatic verification of spoken text vs subtitle text',
                'No proof of exact frame edits; scene and audio flags are review candidates',
                'Safe-zone test only for externally supplied bounding boxes; estimated margins, not official universal dimensions',
                'Face detector misses profile and small faces; no automatic artistic verdict']}
    (output/'run_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    with open(output/'issues.csv','w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['clip','severity','timecode','code','detail','action','evidence']);w.writeheader()
        for r in results:
            for i in r['issues']:w.writerow({'clip':r['clip_id'],**{k:i.get(k,'') for k in w.fieldnames if k!='clip'}})
    if comparisons:(output/'compare.json').write_text(json.dumps(comparisons,ensure_ascii=False,indent=2),encoding='utf-8')
    export_html(output,results,comparisons)
    print(json.dumps({'success':True,'clips':len(results),'runtime_s':summary['analysis_time_s'],
                      'cache_hits':sum(x['cache_hit'] for x in results),
                      'issues':sum(len(x['issues']) for x in results),
                      'output':str(output)},ensure_ascii=False))
    return 0

if __name__=='__main__':
    ap=argparse.ArgumentParser(description='Timа Осаdok video QA engine')
    ap.add_argument('--input',required=True,help='ZIP, directory or single MP4')
    ap.add_argument('--output',required=True,help='Output directory')
    ap.add_argument('--srt-dir',help='ASR-derived SRT in separate directory')
    ap.add_argument('--boxes',help='JSON of subtitle screen bounding boxes, optional')
    ap.add_argument('--platform',choices=list(SAFE_MARGIN),default='tiktok')
    ap.add_argument('--workers',type=int,default=3)
    ap.add_argument('--locks',help='JSON explicit approved creative exceptions; only specified visual flags are annotated')
    ap.add_argument('--compare-old',help='Path to old run_summary.json or report directory')
    sys.exit(run(ap.parse_args()))
