#!/usr/bin/env python3
"""Prototype of durable role-handoff rules, NOT a deployed multi-agent service.

The production orchestrator must bind transitions to authenticated user identities,
real media artifacts, agent runtimes, and job queue callbacks; this module only
models the transitions and protects final publication approval.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

class TransitionError(ValueError):
    pass

@dataclass
class TeamWorkflow:
    project_id: str
    state: str = 'NEW'
    revision_count: int = 0
    max_revisions: int = 3
    human_audio_verified: bool = False
    unresolved_blockers: list[str] = field(default_factory=list)
    events: list[dict[str, Any]] = field(default_factory=list)

    def transition(self, actor: str, event: str, *, evidence: str = '', blockers: list[str] | None = None):
        """A deterministic workflow prototype. Never runs agents or publishes anything."""
        expected = {
            ('NEW', 'tima', 'SUBMIT'): 'JOHN_BRIEF',
            ('JOHN_BRIEF', 'john', 'BRIEF_READY'): 'SEMEN_EDIT',
            ('SEMEN_EDIT', 'semen', 'EXPORT_READY'): 'QC_GATE',
            ('QC_GATE', 'qc', 'QC_FAIL'): 'SEMEN_EDIT',
            ('QC_GATE', 'qc', 'QC_PASS'): 'RICK_REVIEW',
            ('RICK_REVIEW', 'rick', 'REWORK'): 'SEMEN_EDIT',
            ('RICK_REVIEW', 'rick', 'ART_APPROVE'): 'JOHN_FINAL_CHECK',
            ('JOHN_FINAL_CHECK', 'john', 'STRATEGY_APPROVE'): 'READY_FOR_TIMA',
            ('JOHN_FINAL_CHECK', 'john', 'REWORK'): 'SEMEN_EDIT',
            ('READY_FOR_TIMA', 'tima', 'REJECT'): 'SEMEN_EDIT',
            ('READY_FOR_TIMA', 'tima', 'APPROVE'): 'APPROVED_BY_TIMA',
        }
        key = (self.state, actor, event)
        if key not in expected:
            raise TransitionError(f'Invalid transition: {self.state} / {actor} / {event}')
        if not evidence.strip():
            raise TransitionError('Every transition requires an evidence or artifact reference')
        if event == 'QC_PASS' and (blockers or []):
            raise TransitionError('QC_PASS cannot include unresolved P0/P1 blockers')
        if event == 'ART_APPROVE' and not self.human_audio_verified:
            raise TransitionError('Rick cannot sign final audio-visual approval without verified human audio review')
        if event in ('ART_APPROVE', 'STRATEGY_APPROVE', 'APPROVE') and self.unresolved_blockers:
            raise TransitionError('No approval with unresolved blockers')
        nxt=expected[key]
        nrev=self.revision_count + (nxt=='SEMEN_EDIT' and self.state!='JOHN_BRIEF')
        if nrev > self.max_revisions:
            nxt='NEEDS_TIMA_DECISION'  # no indefinite autonomous repair loop
        if event == 'QC_FAIL':
            if not blockers:
                raise TransitionError('QC_FAIL requires a concrete issue list')
            self.unresolved_blockers=list(blockers)
            self.human_audio_verified=False
        elif event == 'REWORK':
            if not blockers:
                raise TransitionError('REWORK requires a concrete issue list')
            self.unresolved_blockers=list(blockers)
            self.human_audio_verified=False
        elif event == 'QC_PASS':
            self.unresolved_blockers=[]
        elif event == 'EXPORT_READY':
            self.human_audio_verified=False  # each new render invalidates signoff
        self.revision_count=nrev
        self.events.append({'from':self.state,'to':nxt,'actor':actor,'event':event,
                            'evidence':evidence,'blockers':blockers or []})
        self.state=nxt
        return nxt

    def verify_human_audio(self, *, verified_by: str, evidence: str):
        if self.state != 'RICK_REVIEW':
            raise TransitionError('Human audio verification can only be attached during final review')
        if verified_by not in ('semen','tima','audio_reviewer') or not evidence.strip():
            raise TransitionError('Human audio verifier and evidence required')
        self.human_audio_verified=True
        self.events.append({'actor':verified_by,'event':'HUMAN_AUDIO_VERIFIED','evidence':evidence})

    def tima_resolve_limit(self, *, evidence: str, resume: bool):
        if self.state != 'NEEDS_TIMA_DECISION' or not evidence.strip():
            raise TransitionError('Only an escalated workflow can be resolved')
        self.events.append({'actor':'tima','event':'LIMIT_DECISION','evidence':evidence,'resume':resume})
        self.state='SEMEN_EDIT' if resume else 'CANCELLED'
        if resume:
            self.max_revisions += 1
        return self.state
