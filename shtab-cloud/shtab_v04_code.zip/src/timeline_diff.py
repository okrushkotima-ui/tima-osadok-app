#!/usr/bin/env python3
"""Compare editor-supplied edit-decision manifests. No proof of MP4 contents.
Manifests are authoritative only if exported by the editor from the actual timeline.
"""
import argparse, hashlib, json
from pathlib import Path

FIELDS=('source_sha256','source_in_s','source_out_s','speed','crop','scale','color','audio','subtitle_sha256','transition_in','transition_out')
def digest(obj):
    payload={k:obj.get(k) for k in FIELDS}
    return hashlib.sha256(json.dumps(payload,sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()

def compare(old,new):
    out={'old_version':old.get('version'),'new_version':new.get('version'),'clips':{},
         'important':'Matching timeline segment signatures can reuse SOURCE analyses, but rendered video/audio and boundaries still need QA.'}
    for clipid in sorted(set(old.get('clips',{}))|set(new.get('clips',{}))):
        a={x['segment_id']:x for x in old.get('clips',{}).get(clipid,[])}
        b={x['segment_id']:x for x in new.get('clips',{}).get(clipid,[])}
        same=[k for k in a.keys()&b.keys() if digest(a[k])==digest(b[k])]
        changed=[k for k in a.keys()&b.keys() if digest(a[k])!=digest(b[k])]
        inserted=list(b.keys()-a.keys());removed=list(a.keys()-b.keys())
        out['clips'][clipid]={'unchanged_segment_ids':sorted(same),'changed_segment_ids':sorted(changed),
                              'inserted_segment_ids':sorted(inserted),'removed_segment_ids':sorted(removed),
                              'render_qc_required':True,'check_cut_boundaries':sorted(set(changed+inserted+removed))}
    return out
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('old');p.add_argument('new');p.add_argument('--output')
    args=p.parse_args();result=compare(json.loads(Path(args.old).read_text(encoding='utf-8')),
                                       json.loads(Path(args.new).read_text(encoding='utf-8')))
    s=json.dumps(result,ensure_ascii=False,indent=2)
    if args.output:Path(args.output).write_text(s,encoding='utf-8')
    print(s)
