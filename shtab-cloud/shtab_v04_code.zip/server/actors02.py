"""Real structured Responses API gateway for two role configurations.

This requires an external OpenAI API key, billed independently of ChatGPT.
No existing GPT chats are invoked. Offline SDK/client tests are NOT real API calls.
"""
from __future__ import annotations
import json,os,time
from .actors import ROLE_RULES,ModelUnavailable

SCHEMA={
 'type':'object','additionalProperties':False,
 'properties':{
  'role':{'type':'string','enum':['JOHN','RICK']},
  'review_scope':{'type':'string','enum':['TEXT_AND_METADATA_ONLY']},
  'summary':{'type':'string'},
  'observations':{'type':'array','items':{
   'type':'object','additionalProperties':False,'properties':{
    'clip_id':{'type':'string'},'timecode':{'type':'string'},
    'evidence':{'type':'string'},'action':{'type':'string'},'confidence':{'type':'string','enum':['LOW','MEDIUM','HIGH']}
   },'required':['clip_id','timecode','evidence','action','confidence']}},
  'uncertainties':{'type':'array','items':{'type':'string'}},
  'verdict':{'type':'string','enum':['TEXT_REVIEW_COMPLETE','NEEDS_MEDIA_EVIDENCE','NEEDS_REVISION']}
 },
 'required':['role','review_scope','summary','observations','uncertainties','verdict']
}

class StructuredRoleGateway:
 def __init__(self,client=None):
  self.model=os.environ.get('OPENAI_MODEL','gpt-6.1-sol')
  # Explicitly injected clients are useful for tests, but must never be
  # treated as proof of a genuine provider call merely by copying resp_ IDs.
  self._client_injected = client is not None
  if client is not None:self.client=client
  elif os.environ.get('OPENAI_API_KEY'):
   try:from openai import OpenAI
   except ImportError as e:raise ModelUnavailable('OpenAI SDK не установлен, установить openai>=2,<4 на сервере') from e
   self.client=OpenAI(timeout=90,max_retries=0)
  else:self.client=None
 @property
 def enabled(self):return self.client is not None
 @property
 def real_provider_eligible(self):
  # This is a trusted deployment gate, NOT cryptographic attestation.
  return self.enabled and not self._client_injected
 def call(self,role,prompt):
  if not self.enabled:raise ModelUnavailable('OPENAI_API_KEY не задан; реальные агентные вызовы отключены')
  if role not in ('JOHN','RICK'):raise ValueError('Unsupported phase 0.2 role')
  model=os.environ.get('OPENAI_MODEL_'+role,self.model)
  instructions=ROLE_RULES[role]+('\nСтруктурируй ответ строго по схеме JSON. В review_scope всегда TEXT_AND_METADATA_ONLY.\n'
   'Это не полная проверка аудио/видео. Не придумывай цитат. Для каждой рекомендации укажи источник.\n'
   'Для роли JOHN: сценарная карта и конкретные хуки. Для роли RICK: независимая проверка сценария, а НЕ AV-приёмка.')
  start=time.monotonic()
  r=self.client.responses.create(model=model,instructions=instructions,input=prompt,
    text={'format':{'type':'json_schema','name':'shtab_role_review_v02','strict':True,'schema':SCHEMA}})
  body=r.output_text or ''
  if not body:raise ValueError('Empty or refused model answer: not an AI review')
  parsed=json.loads(body)
  if parsed.get('role')!=role or parsed.get('review_scope')!='TEXT_AND_METADATA_ONLY':
   raise ValueError('Model returned a mismatching role or falsely expanded evidence scope')
  if not isinstance(parsed.get('observations'),list) or not isinstance(parsed.get('uncertainties'),list):
   raise ValueError('Model returned incomplete structured review')
  return {'text':json.dumps(parsed,ensure_ascii=False,indent=2),'provider':'OpenAI Responses API',
   'model':getattr(r,'model',model),'response_id':r.id,'elapsed_ms':round((time.monotonic()-start)*1000),
   'input_tokens':getattr(getattr(r,'usage',None),'input_tokens',None),
   'output_tokens':getattr(getattr(r,'usage',None),'output_tokens',None)}
