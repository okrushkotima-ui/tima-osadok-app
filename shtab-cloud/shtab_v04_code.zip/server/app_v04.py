"""Private LOCAL API for phase 0.2. Not an OAuth-enabled Internet service."""
from __future__ import annotations
import os, secrets, time, threading, uuid
from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException, UploadFile, File, Depends, Request
from fastapi.responses import FileResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, Field
from .store import Store
from .phase02 import SliceError, ALLOWED
from .fullcycle import FullCycle

ROOT=Path(__file__).resolve().parent.parent
MAX_UPLOAD=int(os.environ.get('SHTAB_MAX_UPLOAD_BYTES',str(512*1024*1024)))

class NewProject(BaseModel):
 title:str=Field(min_length=3,max_length=160)
 goal:str=Field(min_length=3,max_length=6000)


def create_app_v04(data_dir=None,token=None,start_worker=True,agent=None):
 folder=Path(data_dir or os.environ.get('SHTAB_DATA_DIR',str(ROOT/'private_data'))).resolve()
 folder.mkdir(parents=True,exist_ok=True)
 secret=token or os.environ.get('SHTAB_ACCESS_TOKEN')
 if not secret:raise RuntimeError('SHTAB_ACCESS_TOKEN обязателен')
 db=Store(folder/'shtab.sqlite3')
 coord=FullCycle(db,folder,agent)
 security=HTTPBearer(auto_error=False)

 def auth(v:HTTPAuthorizationCredentials=Depends(security)):
  if v is None or not secrets.compare_digest(v.credentials,secret):
   raise HTTPException(401,'Доступ запрещён',headers={'WWW-Authenticate':'Bearer'})

 def pid_ok(pid):
  if not db.project(pid) or not db.one('SELECT project_id FROM fullcycle_meta WHERE project_id=?',(pid,)):
   raise HTTPException(404,'Проект не найден')
  return pid

 def safe(fn,*args):
  try:return fn(*args)
  except SliceError as e:raise HTTPException(409,str(e)) from e

 def worker_loop(stop):
  while not stop.is_set():
   work=coord.process_one()
   if not work:stop.wait(.5)

 @asynccontextmanager
 async def lifespan(app):
  stop=threading.Event();t=None
  if start_worker:
   t=threading.Thread(target=worker_loop,args=(stop,),daemon=True);t.start()
  yield
  stop.set()
  if t:t.join(timeout=2)

 app=FastAPI(title='Штаб Тимы Осадка — 0.4 unified local',version='0.4.0',docs_url=None,redoc_url=None,openapi_url=None,lifespan=lifespan)
 app.state.coord=coord;app.state.store=db
 @app.middleware('http')
 async def secure(req:Request,call_next):
  result=await call_next(req)
  result.headers['Cache-Control']='no-store'
  result.headers['X-Content-Type-Options']='nosniff'
  result.headers['X-Frame-Options']='DENY'
  result.headers['Content-Security-Policy']="default-src 'self'; img-src 'self' data:; connect-src 'self'; script-src 'self'; style-src 'self'; frame-ancestors 'none'"
  return result

 @app.get('/')
 def home():return FileResponse(ROOT/'static'/'shtab04.html')
 @app.get('/api/health',dependencies=[Depends(auth)])
 def health():return {'version':'0.4.0','local_mvp':True,'model_api_configured':bool(getattr(coord.agent,'enabled',False)),
  'mcp_chatgpt_connected':False,'mcp_oauth_configured':False,'editor':'WAITING_FOR_EDITOR','publish':'DISABLED','unified_coordinator':True,'gate_g1_live_calls':False}
 @app.get('/api/projects',dependencies=[Depends(auth)])
 def projects():return db.rows("SELECT p.id,p.title,p.goal,p.state,p.stopped,sm.sources_sealed FROM projects p JOIN slice_meta sm ON sm.project_id=p.id JOIN fullcycle_meta fc ON fc.project_id=p.id ORDER BY p.created_at DESC")
 @app.post('/api/projects',dependencies=[Depends(auth)])
 def create(req:NewProject):return coord.snapshot(coord.create(req.title,req.goal))
 @app.get('/api/projects/{pid}',dependencies=[Depends(auth)])
 def get(pid:str):return coord.snapshot(pid_ok(pid))
 @app.post('/api/projects/{pid}/sources',dependencies=[Depends(auth)])
 async def upload(pid:str,file:UploadFile=File(...)):
  pid_ok(pid)
  name=Path(file.filename or 'unnamed').name
  if Path(name).suffix.lower() not in ALLOWED:raise HTTPException(400,'Разрешены MP4/MOV/MKV/SRT/ZIP')
  temp=folder/pid/f'.incomplete-{uuid.uuid4().hex}'
  temp.parent.mkdir(parents=True,exist_ok=True)
  size=0
  try:
   with temp.open('wb') as output:
    while True:
     b=await file.read(1024*1024)
     if not b:break
     size+=len(b)
     if size>MAX_UPLOAD:raise HTTPException(413,'Превышен лимит размера исходника')
     output.write(b)
   return safe(coord.register_file,pid,temp,name)
  finally:
   temp.unlink(missing_ok=True)
   await file.close()
 @app.post('/api/projects/{pid}/seal',dependencies=[Depends(auth)])
 def seal(pid:str):return safe(coord.seal,pid_ok(pid))
 @app.post('/api/projects/{pid}/stop',dependencies=[Depends(auth)])
 def stop(pid:str):coord.stop(pid_ok(pid));return {'state':'STOPPED'}
 @app.post('/api/projects/{pid}/retry-blocked',dependencies=[Depends(auth)])
 def retry_blocked(pid:str):return safe(coord.retry_blocked,pid_ok(pid))
 @app.get('/api/projects/{pid}/gates',dependencies=[Depends(auth)])
 def gates(pid:str):return coord.gates(pid_ok(pid))
 @app.get('/api/projects/{pid}/evidence',dependencies=[Depends(auth)])
 def evidence(pid:str):return safe(coord.evidence,pid_ok(pid))
 @app.get('/api/projects/{pid}/assets/{aid}',dependencies=[Depends(auth)])
 def download(pid:str,aid:str):
  pid_ok(pid)
  a=db.one('SELECT stored_name,original_name FROM assets WHERE project_id=? AND id=?',(pid,aid))
  if not a:raise HTTPException(404)
  return FileResponse(folder/pid/'assets'/a['stored_name'],filename=a['original_name'])
 @app.post('/api/worker/once',dependencies=[Depends(auth)])
 def run_once():return coord.process_one() or {'status':'idle'}
 return app
