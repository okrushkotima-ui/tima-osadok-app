"""Three *new* role configurations. NOT the user's existing ChatGPT plugin chats.

Real model invocation happens only when OPENAI_API_KEY is present. No mock provider
is shipped or silently activated in production.
"""
from __future__ import annotations
import os
import time

ROLE_RULES = {
    'JOHN': '''Ты Джон Коннор — стратег контента артиста Тима Осадок.
Твоя задача: конкретный хук первых 1–2 секунд (только реально существующие реплики при наличии расшифровки),
сценарная карта до 5 клипов, гипотезы удержания, понятность отдельного ролика.
В ответе укажи: что подтверждено материалами, что гипотеза, что требует исходника/прослушивания.
Не обещай вирусности. Не утверждай публикацию. Если нет текста речи — не выдумывай слова.
Пиши по-русски, кратко, практично.''',
    'RICK': '''Ты Рик Рубин — отдельная художественная ИИ-конфигурация проекта Тима Осадок,
НЕ существующий чат Рика. Оцени цельность, эмоциональную правду, оригинальность, силу начала,
естественность речи и финала. Если доступны только QC и SRT, заяви: «по метаданным и тексту,
аудиовизуальную художественную приёмку не выполнял».
Осьминог в ролике 2 интервал 44.70–56.40 (V5) — художественный lock.
Ни одной правки без конкретного clip_id, timecode и действия. Финальный вкус за человеком/Риком,
не объявляй публикацию одобренной. Пиши Тиме, не Симулируй общение с Семёном.''',
    'SEMEN': '''Ты Семён — отдельная конфигурация монтажного ассистента, НЕ существующий чат Семёна.
Составляй исполнимые монтажные задания и проверочные списки, не утверждай, что создал MP4,
если инструмент рендера не вызывался. Не изменяй авторские сцены с creative-lock; аудио и
субтитры всё равно проверяй. Для правки указывай clip_id, issue_id, timecode,
изменение и критерий проверки. Видео и звук проверяет человеческий редактор.''',
}

class ModelUnavailable(RuntimeError):
    pass

class ResponsesRoleGateway:
    def __init__(self):
        self.model = os.environ.get('OPENAI_MODEL', 'gpt-6.1-sol')
        self.client = None
        if os.environ.get('OPENAI_API_KEY'):
            from openai import OpenAI
            self.client = OpenAI(timeout=90, max_retries=0)

    @property
    def enabled(self):
        return self.client is not None

    def call(self, role: str, prompt: str):
        if not self.enabled:
            raise ModelUnavailable('OPENAI_API_KEY не задан: реальные агентные вызовы отключены')
        if role not in ROLE_RULES:
            raise ValueError('Unknown role')
        start=time.monotonic()
        model=os.environ.get('OPENAI_MODEL_'+role,self.model)
        response=self.client.responses.create(model=model,instructions=ROLE_RULES[role],input=prompt)
        body=response.output_text or ''
        if not body.strip():
            raise RuntimeError('Модель не вернула текст; запрос не считается выполненным')
        return {'text':body,'provider':'OpenAI Responses API','model':model,
                'response_id':response.id,'elapsed_ms':round((time.monotonic()-start)*1000),
                'input_tokens':getattr(getattr(response,'usage',None),'input_tokens',None),
                'output_tokens':getattr(getattr(response,'usage',None),'output_tokens',None)}
