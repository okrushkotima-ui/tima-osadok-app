"""Transactional SQLite event log and project registry; survives server restart."""
import json, sqlite3, threading, time, uuid
from contextlib import contextmanager
from pathlib import Path

SCHEMA = '''
PRAGMA journal_mode=WAL;
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS projects(
 id TEXT PRIMARY KEY, title TEXT NOT NULL, goal TEXT NOT NULL,
 state TEXT NOT NULL DEFAULT 'NEW', rebuilds INTEGER NOT NULL DEFAULT 0,
 created_at REAL NOT NULL, updated_at REAL NOT NULL,
 editor_checked INTEGER NOT NULL DEFAULT 0, editor_note TEXT NOT NULL DEFAULT '',
 rick_first INTEGER NOT NULL DEFAULT 0, john_final INTEGER NOT NULL DEFAULT 0,
 rick_final INTEGER NOT NULL DEFAULT 0, stopped INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS assets(
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id),
 clip_id TEXT, version INTEGER, kind TEXT NOT NULL, original_name TEXT NOT NULL,
 stored_name TEXT NOT NULL, sha256 TEXT NOT NULL, bytes INTEGER NOT NULL,
 created_at REAL NOT NULL,
 UNIQUE(project_id, sha256, kind, version, clip_id)
);
CREATE TABLE IF NOT EXISTS issues(
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id),
 clip_id TEXT NOT NULL, version INTEGER NOT NULL, code TEXT NOT NULL,
 timecode TEXT NOT NULL, time_s REAL NOT NULL, severity TEXT NOT NULL,
 status TEXT NOT NULL, detail TEXT NOT NULL, action TEXT NOT NULL,
 evidence_uri TEXT, accepted_by TEXT, resolved_evidence TEXT NOT NULL DEFAULT '',
 created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS messages(
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id),
 actor TEXT NOT NULL, channel TEXT NOT NULL, text TEXT NOT NULL,
 provider TEXT NOT NULL DEFAULT '', provenance TEXT NOT NULL DEFAULT '',
 created_at REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS jobs(
 id TEXT PRIMARY KEY, project_id TEXT NOT NULL REFERENCES projects(id),
 kind TEXT NOT NULL, payload_json TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
 idempotency_key TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
 error TEXT NOT NULL DEFAULT '', created_at REAL NOT NULL, updated_at REAL NOT NULL,
 UNIQUE(project_id,idempotency_key)
);
CREATE TABLE IF NOT EXISTS events(
 sequence INTEGER PRIMARY KEY AUTOINCREMENT,
 project_id TEXT NOT NULL REFERENCES projects(id), clip_id TEXT, version INTEGER,
 actor TEXT NOT NULL, event TEXT NOT NULL, artifact_sha256 TEXT, issue_id TEXT,
 timecode TEXT, severity TEXT, evidence_uri TEXT, accepted_by TEXT,
 detail_json TEXT NOT NULL DEFAULT '{}', created_at REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_jobs_pending ON jobs(status,created_at);
CREATE INDEX IF NOT EXISTS idx_events_project ON events(project_id,sequence);
'''

class Store:
 def __init__(self,db_path):
  self.path=Path(db_path);self.path.parent.mkdir(parents=True,exist_ok=True)
  self.lock=threading.RLock()
  with self.tx() as c:c.executescript(SCHEMA)
  try:self.path.chmod(0o600)
  except OSError:pass
  self.recover_inflight_jobs()
 @contextmanager
 def tx(self):
  with self.lock:
   c=sqlite3.connect(self.path,timeout=10,isolation_level=None)
   c.row_factory=sqlite3.Row
   try:
    c.execute('PRAGMA foreign_keys=ON');c.execute('BEGIN IMMEDIATE')
    yield c
    c.commit()
   except:
    c.rollback();raise
   finally:c.close()
 def recover_inflight_jobs(self):
  # Uncertain calls are never automatically replayed: a real API call may have completed
  # immediately before a crash. Explicit operator retry prevents duplicate charges/renders.
  with self.tx() as c:
   jobs=c.execute("SELECT id,project_id,kind FROM jobs WHERE status='running'").fetchall()
   for job in jobs:
    c.execute("UPDATE jobs SET status='interrupted',error='Незавершённая задача после перезапуска; проверь результат перед повтором' WHERE id=?",(job['id'],))
    self.event(c,job['project_id'],'COORDINATOR','JOB_INTERRUPTED_ON_RESTART',detail={'job_id':job['id'],'kind':job['kind']})
 def rows(self,query,params=()):
  with self.tx() as c:return [dict(x) for x in c.execute(query,params)]
 def one(self,query,params=()):
  with self.tx() as c:
   x=c.execute(query,params).fetchone();return dict(x) if x else None
 def project(self,pid):return self.one('SELECT * FROM projects WHERE id=?',(pid,))
 def create(self,title,goal):
  pid=str(uuid.uuid4());now=time.time()
  with self.tx() as c:
   c.execute('INSERT INTO projects(id,title,goal,created_at,updated_at) VALUES(?,?,?,?,?)',(pid,title,goal,now,now))
   self.event(c,pid,'TIMA','PROJECT_CREATED',detail={'title':title})
  return pid
 def event(self,c,pid,actor,event,clip_id=None,version=None,artifact_sha256=None,issue_id=None,timecode=None,severity=None,evidence_uri=None,accepted_by=None,detail=None):
  c.execute('INSERT INTO events(project_id,clip_id,version,actor,event,artifact_sha256,issue_id,timecode,severity,evidence_uri,accepted_by,detail_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)',
  (pid,clip_id,version,actor,event,artifact_sha256,issue_id,timecode,severity,evidence_uri,accepted_by,json.dumps(detail or {},ensure_ascii=False),time.time()))
 def state(self,c,pid,state):
  c.execute('UPDATE projects SET state=?,updated_at=? WHERE id=?',(state,time.time(),pid))
  self.event(c,pid,'COORDINATOR','STATE_CHANGED',detail={'state':state})
 def queue(self,c,pid,kind,payload,key):
  jid=str(uuid.uuid4());t=time.time()
  c.execute('INSERT OR IGNORE INTO jobs(id,project_id,kind,payload_json,idempotency_key,created_at,updated_at) VALUES(?,?,?,?,?,?,?)',(jid,pid,kind,json.dumps(payload,ensure_ascii=False),key,t,t))
  res=c.execute('SELECT id FROM jobs WHERE project_id=? AND idempotency_key=?',(pid,key)).fetchone()[0]
  if res==jid:self.event(c,pid,'COORDINATOR','JOB_QUEUED',detail={'job_id':jid,'kind':kind})
  return res
 def message(self,c,pid,actor,text,channel='chat',provider='',provenance=''):
  mid=str(uuid.uuid4());c.execute('INSERT INTO messages(id,project_id,actor,channel,text,provider,provenance,created_at) VALUES(?,?,?,?,?,?,?,?)',(mid,pid,actor,channel,text,provider,provenance,time.time()))
  self.event(c,pid,actor,'MESSAGE',detail={'message_id':mid,'provider':provider,'provenance':provenance})
  return mid
 def snapshot(self,pid):
  p=self.project(pid)
  if not p:return None
  p['assets']=self.rows('SELECT id,clip_id,version,kind,original_name,sha256,bytes,created_at FROM assets WHERE project_id=? ORDER BY created_at',(pid,))
  p['messages']=self.rows('SELECT * FROM messages WHERE project_id=? ORDER BY created_at',(pid,))
  p['issues']=self.rows('SELECT * FROM issues WHERE project_id=? ORDER BY version,time_s',(pid,))
  p['jobs']=self.rows('SELECT id,kind,status,attempts,error,created_at FROM jobs WHERE project_id=? ORDER BY created_at',(pid,))
  p['events']=self.rows('SELECT * FROM events WHERE project_id=? ORDER BY sequence',(pid,))
  for x in p['events']:
   x['detail']=json.loads(x.pop('detail_json'))
  return p
