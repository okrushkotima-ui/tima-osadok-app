"""Unified audited workflow v0.4. Not a ChatGPT MCP / production renderer.

One active coordinator: inherits Phase02's sealed source ingest, Responses API
calls, provenance checks and transactional queue; makes G1 lead to a blocked
editor stage, not Tima artistic approval. The production continuation is
contract-gated and cannot be forged by text or test doubles.
"""
from __future__ import annotations
import hashlib, json, os, time
from pathlib import Path
from .phase02 import Phase02, SliceError

FULLCYCLE_DDL="""
CREATE TABLE IF NOT EXISTS fullcycle_meta(
 project_id TEXT PRIMARY KEY REFERENCES projects(id),
 workflow_version TEXT NOT NULL,
 renderer_enabled INTEGER NOT NULL DEFAULT 0,
 mcp_connected INTEGER NOT NULL DEFAULT 0,
 av_review_complete INTEGER NOT NULL DEFAULT 0,
 approved_version_sha TEXT NOT NULL DEFAULT '',
 created_at REAL NOT NULL);
CREATE TABLE IF NOT EXISTS fullcycle_reworks(
 project_id TEXT NOT NULL REFERENCES projects(id),
 clip_id TEXT NOT NULL,
 rebuilds INTEGER NOT NULL DEFAULT 0 CHECK(rebuilds>=0 AND rebuilds<=3),
 PRIMARY KEY(project_id,clip_id));
"""

STAGES=(
 'WAITING_FOR_SOURCES','JOHN_PENDING','RICK_PENDING',
 'WAITING_FOR_EDITOR','RENDER_READY','QC_PENDING','QC_PASSED',
 'RICK_AV_REVIEW_PENDING','BLOCKED_AV_EVIDENCE','ART_APPROVED',
 'SEMEN_REWORK_PENDING','JOHN_FINAL_PENDING','JOHN_FINAL_DONE',
 'RICK_FINAL_PENDING','READY_FOR_TIMA','APPROVED_BY_TIMA',
 'NEEDS_TIMA_DECISION','STOPPED')

class FullCycle(Phase02):
 def __init__(self,db,data_dir,agent=None):
  super().__init__(db,data_dir,agent=agent)
  with self.db.tx() as c:c.executescript(FULLCYCLE_DDL)

 def create(self,title,goal):
  pid=super().create(title,goal)
  with self.db.tx() as c:
   c.execute('INSERT INTO fullcycle_meta(project_id,workflow_version,created_at) VALUES(?,?,?)',
    (pid,'0.4',time.time()))
   self.db.event(c,pid,'COORDINATOR','FULLCYCLE_WORKFLOW_REGISTERED',
    detail={'same_database':True,'same_queue':True,'legacy_coordinator_inactive':True,
     'g1_provider_calls_required':2,'renderer_connected':False,'publish_api':False})
  return pid

 def _managed(self,pid):
  if not self.db.one('SELECT project_id FROM fullcycle_meta WHERE project_id=?',(pid,)):
   raise SliceError('Этот проект не находится под единым координатором v0.4')

 def gates(self,pid):
  self._managed(pid)
  p=self.db.project(pid)
  runs=self.db.rows('SELECT actor,verified,response_id,review_scope,input_sha256,output_sha256,evidence_sha256,provider,model,input_tokens,output_tokens FROM slice_runs WHERE project_id=? ORDER BY created_at,id',(pid,))
  def authentic_record(x):
   # Flags are created by the protected real provider branch; these additional
   # invariants prevent incomplete receipts from satisfying Gate 1.
   return (bool(x['verified']) and x['provider']=='OpenAI Responses API' and
    bool(x['model']) and isinstance(x['response_id'],str) and x['response_id'].startswith('resp_') and
    x['review_scope']=='TEXT_AND_METADATA_ONLY' and
    x['input_tokens'] is not None and x['input_tokens']>=0 and
    x['output_tokens'] is not None and x['output_tokens']>=0 and
    all(isinstance(x[k],str) and len(x[k])==64 and all(c in '0123456789abcdef' for c in x[k])
     for k in ('input_sha256','output_sha256','evidence_sha256')))
  g1=any(a['actor']=='JOHN' and b['actor']=='RICK' and
    authentic_record(a) and authentic_record(b) and
    a['response_id']!=b['response_id'] and
    a['evidence_sha256']==b['evidence_sha256']
    for a,b in zip(runs,runs[1:]))
  return {'G1':{'passed':g1,'detail':'Two real verified Responses API calls with same sealed evidence' if g1 else 'Live provider calls not verified'},
   'G2':{'passed':False,'detail':'Private authenticated MCP was not connected inside ChatGPT'},
   'G3':{'passed':False,'detail':'No renderer API / verified output MP4 and SRT'},
   'G4':{'passed':False,'detail':'No complete audiovisual review; SRT alone never approves art'},
   'G5':{'passed':False,'detail':'Full autonomous review/rebuild/final acceptance cycle not executed'},
   'readiness':'NOT_PRODUCTION_READY','publish_api':'DISABLED',
   'project_state':p['state'],'stopped':bool(p['stopped'])}

 def snapshot(self,pid):
  self._managed(pid)
  snap=super().snapshot(pid)
  snap['fullcycle']={'workflow_version':'0.4','gates':self.gates(pid),
   'next_real_step':'LIVE_JOHN_RICK' if not self.gates(pid)['G1']['passed'] else 'CHATGPT_MCP',
   'automatic_render_enabled':False,'automatic_art_approval_enabled':False,
   'legacy_state_machine_active':False,'publish_api':'DISABLED'}
  return snap

 def insist_av(self,pid,clip_id,revision,artifact_sha256,review_scope):
  """Fail closed, even if a caller presents a plausible narrative or SRT.

  This version has NO verified ingest of actual editor outputs, so all art
  approvals must be blocked regardless of the requested review_scope.
  """
  self._managed(pid)
  if self.db.project(pid)['stopped']:raise SliceError('Проект остановлен')
  if review_scope!='AV_REVIEW_COMPLETE' or not artifact_sha256:
   raise SliceError('BLOCKED_AV_EVIDENCE: подтверждение SRT/метаданных не является просмотром видео и проверкой звука')
  raise SliceError('BLOCKED_AV_EVIDENCE: отсутствует верифицированный MP4 версии и AV-подтверждение; статус ART_APPROVED запрещён')

 def render_request(self,pid,clip_id,issue_ids=()):
  """No fabricated rendering or counters; unavailable editor is a hard gate."""
  self._managed(pid)
  p=self.db.project(pid)
  if p['stopped']:raise SliceError('STOPPED')
  with self.db.tx() as c:
   fc=c.execute('SELECT renderer_enabled FROM fullcycle_meta WHERE project_id=?',(pid,)).fetchone()
   if fc['renderer_enabled']:
    # No renderer callback protocol is implemented in this release.
    raise SliceError('Редактор объявлен включённым без проверенного callback — отказ')
   self.db.event(c,pid,'COORDINATOR','WAITING_FOR_EDITOR',clip_id=clip_id,
    detail={'issue_ids':list(issue_ids),'renderer_job_id':None,'rendered_mp4':False,
     'state_unchanged':True})
  return {'status':'WAITING_FOR_EDITOR','render_job_id':None,'mp4_sha256':None,
   'automatic_rebuild_count_increased':False}

 def mark_rebuild_limit(self,pid,clip_id,submitted_verified_render_count):
  """Pure policy check; not permission to increment based on unverified files."""
  self._managed(pid)
  if submitted_verified_render_count>3:raise SliceError('REBUILD_LIMIT_REACHED')
  if submitted_verified_render_count<0:raise SliceError('Некорректный счётчик')
  return 'NEEDS_TIMA_DECISION' if submitted_verified_render_count==3 else 'REWORK_POSSIBLE_ONLY_WITH_RENDERER'

 def stop(self,pid):
  self._managed(pid)
  return super().stop(pid)
